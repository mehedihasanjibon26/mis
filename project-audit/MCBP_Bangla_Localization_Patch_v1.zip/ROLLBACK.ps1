$ErrorActionPreference = "Stop"
$root = "E:\mis"
$folder = Join-Path $root "project-audit\localization-backups"
if (-not (Test-Path $folder)) { throw "No localization backup folder found." }
$backup = Get-ChildItem $folder -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $backup) { throw "No backups available." }
$files = @(Get-ChildItem $backup.FullName -Recurse -File | Where-Object { $_.Name -ne "new-files.txt" })
foreach ($file in $files) {
    $relative = $file.FullName.Substring($backup.FullName.Length).TrimStart('\','/')
    $target = Join-Path (Join-Path $root "src") $relative
    Copy-Item -LiteralPath $file.FullName -Destination $target -Force
}
$manifest = Join-Path $backup.FullName "new-files.txt"
if (Test-Path $manifest) {
  foreach ($relative in (Get-Content $manifest)) {
    if (-not [string]::IsNullOrWhiteSpace($relative)) {
      $target = Join-Path (Join-Path $root "src") $relative
      if (Test-Path $target) { Remove-Item -LiteralPath $target -Force }
    }
  }
}
Write-Host "SUCCESS: Restored pre-patch files from $($backup.FullName)" -ForegroundColor Green
