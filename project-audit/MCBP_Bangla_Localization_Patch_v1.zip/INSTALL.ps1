$ErrorActionPreference = "Stop"
$root = "E:\mis"
$source = Join-Path $PSScriptRoot "patch\src"
if (-not (Test-Path (Join-Path $root "src\app\page.tsx"))) {
    throw "Expected E:\mis project not found. No changes made."
}
if (-not (Test-Path (Join-Path $source "lib\ui-l10n.ts"))) {
    throw "Patch source files missing. No changes made."
}
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = Join-Path $root ("project-audit\localization-backups\" + $stamp)
$files = @(Get-ChildItem $source -Recurse -File)
# Back up all existing targets before writing any patch files.
foreach ($file in $files) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\','/')
    $target = Join-Path (Join-Path $root "src") $relative
    if (Test-Path $target) {
        $copy = Join-Path $backup $relative
        New-Item -ItemType Directory -Force (Split-Path $copy) | Out-Null
        Copy-Item -LiteralPath $target -Destination $copy -Force
    }
}
# Save new-file list for rollback.
$newFiles = @()
foreach ($file in $files) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\','/')
    $target = Join-Path (Join-Path $root "src") $relative
    if (-not (Test-Path $target)) { $newFiles += $relative }
}
New-Item -ItemType Directory -Force $backup | Out-Null
$newFiles | Out-File (Join-Path $backup "new-files.txt") -Encoding utf8
foreach ($file in $files) {
    $relative = $file.FullName.Substring($source.Length).TrimStart('\','/')
    $target = Join-Path (Join-Path $root "src") $relative
    New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null
    Copy-Item -LiteralPath $file.FullName -Destination $target -Force
}
Write-Host "SUCCESS: Localization patch installed." -ForegroundColor Green
Write-Host "Backup path: $backup" -ForegroundColor Cyan
Write-Host "Files installed: $($files.Count)"
Write-Host "Now run: npx tsc --noEmit; npm run build"
