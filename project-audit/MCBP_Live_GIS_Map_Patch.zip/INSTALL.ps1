$ErrorActionPreference = 'Stop'
Set-Location 'E:\mis'
$utf8 = [System.Text.UTF8Encoding]::new($false)
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pagePath = Join-Path (Get-Location).Path 'src\app\gis\page.tsx'
$componentDest = Join-Path (Get-Location).Path 'src\components\BangladeshLiveMap.tsx'
$mapDir = Join-Path (Get-Location).Path 'public\maps'
$mapFile = Join-Path $mapDir 'bangladesh-divisions.geojson'
$marker = 'MCBP_LIVE_GIS_MAP_V1'
if (-not (Test-Path $pagePath)) { throw 'GIS page missing.' }
if (-not (Test-Path (Join-Path $packageRoot 'src\components\BangladeshLiveMap.tsx'))) { throw 'Patch component missing.' }
$page = [System.IO.File]::ReadAllText($pagePath, $utf8)
if ($page.Contains($marker)) { Write-Host 'Live GIS map already integrated.' -ForegroundColor Yellow; exit 0 }
$startAnchor = '          <div className="gis-map">'
$endAnchor = '          <div style={{' + "`r`n" + '            display: "flex", justifyContent: "space-between",'
$start = $page.IndexOf($startAnchor)
if ($start -lt 0) { throw 'Original GIS map opening anchor not found. No edits made.' }
$end = $page.IndexOf($endAnchor, $start)
if ($end -lt 0) {
  $endAnchor = $endAnchor.Replace("`r`n", "`n")
  $end = $page.IndexOf($endAnchor, $start)
}
if ($end -lt 0) { throw 'GIS legend anchor not found. No edits made.' }
$importAnchor = 'import Link from "next/link";'
if (-not $page.Contains($importAnchor)) { throw 'GIS import anchor missing.' }
New-Item -ItemType Directory -Force $mapDir | Out-Null
if (-not (Test-Path $mapFile)) {
  Write-Host 'Fetching 8 real division boundary geometries from geoBoundaries...'
  $api = 'https://www.geoboundaries.org/api/current/gbOpen/BGD/ADM1/'
  $meta = Invoke-RestMethod -Uri $api -TimeoutSec 45
  if ([int]$meta.admUnitCount -ne 8) { throw 'Boundary provider did not report exactly 8 divisions. No source edits made.' }
  $download = [string]$meta.simplifiedGeometryGeoJSON
  if (-not $download.StartsWith('https://')) { throw 'No trusted GeoJSON download link.' }
  Invoke-WebRequest -Uri $download -OutFile $mapFile -TimeoutSec 90
}
$data = Get-Content -Raw -LiteralPath $mapFile | ConvertFrom-Json
if ($data.type -ne 'FeatureCollection' -or @($data.features).Count -ne 8) { throw 'GeoJSON validation failed. Need exactly 8 features. No source edits made.' }
$names = @($data.features | ForEach-Object { $_.properties.shapeName })
Write-Host ('GeoJSON divisions: ' + ($names -join ', '))
if (@($names | Where-Object { -not $_ }).Count -gt 0) { throw 'Expected shapeName fields not present. Review geometry before install.' }
$replacement = '          {/* MCBP_LIVE_GIS_MAP_V1 */}' + "`r`n" + '          <div className="gis-map">' + "`r`n" + '            <BangladeshLiveMap lang={lang} layer={layer} query={query} selected={division} zoom={zoom} allowAllDivisions={isNational} showPins={showPins} selectionMode={selectionMode} onPinSelect={setSelectedPin} onSelect={(id) => { if (isNational || id === "Rangpur") chooseDivision(id); }} />' + "`r`n" + '          </div>' + "`r`n`r`n"
$newPage = $page.Substring(0,$start) + $replacement + $page.Substring($end)
$newPage = $newPage.Replace($importAnchor, $importAnchor + "`r`n" + 'import BangladeshLiveMap from "../../components/BangladeshLiveMap";')
$subheading = 'Bangladesh divisions · simplified schematic geometry'
$newPage = $newPage.Replace($subheading, '{t("Bangladesh divisions · interactive geographic boundaries", "বাংলাদেশের বিভাগসমূহ · ইন্টারঅ্যাকটিভ ভৌগোলিক সীমানা")}')
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path (Get-Location).Path ('project-audit\gis-live-backups\' + $stamp)
New-Item -ItemType Directory -Force $backupDir | Out-Null
Copy-Item -LiteralPath $pagePath -Destination (Join-Path $backupDir 'gis-page.tsx')
if (Test-Path $componentDest) { Copy-Item $componentDest (Join-Path $backupDir 'BangladeshLiveMap.tsx') }
Write-Host 'Installing Leaflet and types...'
npm install leaflet
if ($LASTEXITCODE -ne 0) { throw 'npm install leaflet failed. GIS page unchanged.' }
npm install -D @types/leaflet @types/geojson
if ($LASTEXITCODE -ne 0) { throw 'npm install types failed. GIS page unchanged.' }
Copy-Item (Join-Path $packageRoot 'src\components\BangladeshLiveMap.tsx') $componentDest -Force
[System.IO.File]::WriteAllText($pagePath,$newPage,$utf8)
Write-Host 'GIS live map installed. Checking TypeScript...' -ForegroundColor Green
npx tsc --noEmit --pretty false
if ($LASTEXITCODE -ne 0) { Write-Host ('TypeScript failure. GIS page backup: ' + $backupDir) -ForegroundColor Red; exit 1 }
npm run build
if ($LASTEXITCODE -ne 0) { Write-Host ('Build failure. GIS page backup: ' + $backupDir) -ForegroundColor Red; exit 1 }
Write-Host 'SUCCESS: GIS live map build passed.' -ForegroundColor Green
Write-Host ('Backup folder: ' + $backupDir)
