
"use client";
import dynamic from "next/dynamic";

import { useEffect, useState } from "react";
import {
  Bell, Search, HeartHandshake, FileText, UserRound, Wallet,
  GraduationCap, MessageSquareWarning, LayoutDashboard, Map, Bot,
  ChartColumn, Network, Headset, Blocks, ShieldCheck, Activity,
  Gauge, PlugZap, GitBranch, Server, LockKeyhole,
  DatabaseBackup, Database, Layers3, BarChart3, Menu,
  RotateCcw, ArrowRight, CalendarDays, Smartphone, type LucideIcon,
} from "lucide-react";

import ApplicationsPanel from "../components/ApplicationsPanel";
import BeneficiariesPanel from "../components/BeneficiariesPanel";
import PayrollPanel from "../components/PayrollPanel";
import GrievancesPanel from "../components/GrievancesPanel";
import TrainingPanel from "../components/TrainingPanel";
import MultiSchemePanel from "../components/MultiSchemePanel";
import GatewayPanel from "../components/GatewayPanel";
import XRoadPanel from "../components/XRoadPanel";
import ObservabilityPanel from "../components/ObservabilityPanel";
import CICDPanel from "../components/CICDPanel";
import SecurityCenterPanel from "../components/SecurityCenterPanel";
import BackupDRPanel from "../components/BackupDRPanel";
import DataGovernancePanel from "../components/DataGovernancePanel";
import PayrollMonitorPanel from "../components/PayrollMonitorPanel";
import AIGovernancePanel from "../components/AIGovernancePanel";
import GISGovernancePanel from "../components/GISGovernancePanel";
import CapacityPanel from "../components/CapacityPanel";
import ReleaseManagementPanel from "../components/ReleaseManagementPanel";
import PerformanceTestPanel from "../components/PerformanceTestPanel";
import NavbarSearch from "../components/NavbarSearch";
import SelfServiceMISPanel from "../components/SelfServiceMISPanel";

import { useDemoStore } from "../lib/demo-store";
import { useBeneficiaryStore } from "../lib/beneficiary-store";
import { usePayrollStore } from "../lib/payroll-store";
import { useGrievanceStore } from "../lib/grievance-store";
import { useTrainingStore } from "../lib/training-store";

type Lang = "en" | "bn";
type NavItem = [string, string, string, LucideIcon];
type NavSection = {
  en: string;
  bn: string;
  items: NavItem[];
};

const sections: NavSection[] = [
  {
    en: "BENEFICIARY LIFECYCLE",
    bn: "উপকারভোগী জীবনচক্র",
    items: [
      ["/applications", "Applications & enrollment", "আবেদন ও নিবন্ধন", FileText],
      ["/beneficiaries", "Beneficiary profiles", "উপকারভোগী প্রোফাইল", UserRound],
      ["/payroll", "Payroll & reconciliation", "পেরোল ও সমন্বয়", Wallet],
      ["/training", "Training", "প্রশিক্ষণ", GraduationCap],
      ["/mobile", "Mobile & field operations", "মোবাইল ও মাঠ কার্যক্রম", Smartphone],
      ["/grievances", "Grievance redress", "অভিযোগ প্রতিকার", MessageSquareWarning],
    ],
  },
  {
    en: "INTELLIGENCE",
    bn: "ইন্টেলিজেন্স",
    items: [
      ["/dashboard", "Executive dashboard", "নির্বাহী ড্যাশবোর্ড", LayoutDashboard],
      ["/gis", "GIS intelligence", "জিআইএস ইন্টেলিজেন্স", Map],
      ["/ai", "AI assistant & agents", "এআই সহকারী ও এজেন্ট", Bot],
      ["/self-service", "Self-service MIS", "সেলফ-সার্ভিস এমআইএস", BarChart3],
    ],
  },
  {
    en: "PLATFORM",
    bn: "প্ল্যাটফর্ম",
    items: [
      ["/data-hub", "Data Hub / API Bank", "ডেটা হাব / এপিআই ব্যাংক", Network],
      ["/helpdesk", "Helpdesk & referrals", "হেল্পডেস্ক ও রেফারেল", Headset],
      ["/schemes", "Module & scheme builder", "মডিউল ও স্কিম বিল্ডার", Blocks],
      ["/multi-scheme", "Multi-scheme management", "মাল্টি-স্কিম ব্যবস্থাপনা", Layers3],
      ["/access", "Users & access", "ব্যবহারকারী ও অ্যাক্সেস", ShieldCheck],
    ],
  },
  {
    en: "PLATFORM OPERATIONS",
    bn: "প্ল্যাটফর্ম অপারেশন",
    items: [
      ["/observability", "Observability", "অবজারভেবিলিটি", Activity],
      ["/capacity", "Capacity & autoscaling", "ক্যাপাসিটি ও অটোস্কেলিং", Gauge],
      ["/release-management", "Release management", "রিলিজ ম্যানেজমেন্ট", ShieldCheck],
      ["/performance-tests", "Load & performance tests", "লোড ও পারফরম্যান্স টেস্ট", ShieldCheck],
      ["/gateway", "API gateway", "এপিআই গেটওয়ে", PlugZap],
      ["/xroad", "X-Road exchange", "এক্স-রোড এক্সচেঞ্জ", Network],
      ["/cicd", "CI/CD pipelines", "সিআই/সিডি পাইপলাইন", GitBranch],
      ["/security-center", "Security Centre & SIEM", "নিরাপত্তা কেন্দ্র", ShieldCheck],
      ["/backup-dr", "Backup & disaster recovery", "ব্যাকআপ ও দুর্যোগ পুনরুদ্ধার", ShieldCheck],
      ["/data-governance", "Data governance", "ডেটা গভর্নেন্স", ShieldCheck],
    ],
  },
  {
    en: "ASSURANCE",
    bn: "অ্যাসিওরেন্স",
    items: [
    ],
  },
  {
    en: "WORKLOADS",
    bn: "ওয়ার্কলোড",
    items: [
      ["/payroll-monitor", "Payroll batch monitor", "পেরোল ব্যাচ মনিটর", Wallet],
      ["/ai-governance", "AI governance", "এআই গভর্নেন্স", ShieldCheck],
      ["/gis-governance", "GIS layer governance", "জিআইএস লেয়ার গভর্নেন্স", ShieldCheck],
    ],
  },
];

const roles = [
  {
    id: "uwao", en: "Upazila Women Affairs Officer",
    bn: "উপজেলা মহিলা বিষয়ক কর্মকর্তা",
    geo: "Kaunia · Rangpur", initials: "NS",
  },
  {
    id: "union_maker", en: "Union Application Maker",
    bn: "ইউনিয়ন আবেদন প্রস্তুতকারী",
    geo: "Kaunia · Rangpur", initials: "UM",
  },
  {
    id: "field", en: "Field Verifier",
    bn: "মাঠ যাচাইকারী",
    geo: "Kaunia", initials: "FV",
  },
  {
    id: "trainer", en: "Community Trainer",
    bn: "কমিউনিটি প্রশিক্ষক",
    geo: "Kaunia · Rangpur", initials: "CT",
  },
  {
    id: "finance", en: "Finance Maker",
    bn: "অর্থ মেকার",
    geo: "Central finance", initials: "FM",
  },
  {
    id: "finance_checker", en: "Finance Checker",
    bn: "অর্থ যাচাইকারী",
    geo: "Central finance", initials: "FC",
  },
  {
    id: "grm", en: "Grievance Redress Officer",
    bn: "অভিযোগ প্রতিকার কর্মকর্তা",
    geo: "Kaunia · Rangpur", initials: "GO",
  },
  {
    id: "executive", en: "Programme Executive / PD",
    bn: "প্রোগ্রাম নির্বাহী / পিডি",
    geo: "National scope", initials: "PD",
  },
  {
    id: "admin", en: "System Administrator",
    bn: "সিস্টেম প্রশাসক",
    geo: "National scope", initials: "SA",
  },
];

const statusNames: Record<string, [string, string]> = {
  draft: ["Draft", "খসড়া"],
  submitted: ["Submitted", "জমা হয়েছে"],
  identity_pending: ["Identity pending", "পরিচয় যাচাই বাকি"],
  identity_verified: ["Identity verified", "পরিচয় যাচাইকৃত"],
  eligibility_passed: ["Eligible", "যোগ্য"],
  eligibility_failed: ["Ineligible", "অযোগ্য"],
  field_pending: ["Field verification pending", "মাঠ যাচাই বাকি"],
  field_completed: ["Field verified", "মাঠ যাচাইকৃত"],
  selection_prepared: ["Selection prepared", "নির্বাচন প্রস্তুত"],
  approval_pending: ["Approval pending", "অনুমোদন বাকি"],
  approved: ["Approved", "অনুমোদিত"],
  rejected: ["Rejected", "বাতিল"],
  returned: ["Returned", "ফেরত"],
  enrolled: ["Enrolled", "নিবন্ধিত"],
};

const nationalRoles = ["executive", "admin"];
const aiRoles = ["executive", "admin", "uwao"];
const standaloneRoutes = ["/executive", "/gis", "/ai", "/data-hub"];

const UnifiedExecutive = dynamic(() => import("./executive/page"), { ssr: false });
const UnifiedDataHub = dynamic(() => import("./data-hub/page"), { ssr: false });
const UnifiedGIS = dynamic(() => import("./gis/page"), { ssr: false });
const UnifiedAI = dynamic(() => import("./ai/page"), { ssr: false });
const UnifiedMobile = dynamic(() => import("./mobile/page"), { ssr: false });
const UnifiedAccess = dynamic(() => import("./access/page"), { ssr: false });
const UnifiedHelpdesk = dynamic(() => import("./helpdesk/page"), { ssr: false });
const UnifiedBuilder = dynamic(() => import("./schemes/page"), { ssr: false });

// MCBP_UNIFIED_MODULE_RENDER_V1
export default function Home() {
  const [lang, setLang] = useState<Lang>("en");
  const [roleId, setRoleId] = useState("uwao");
  const [path, setPath] = useState("/dashboard");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toast, setToast] = useState("");

  const applications = useDemoStore((s) => s.applications);
  const resetApplications = useDemoStore((s) => s.resetDemo);

  const resetProfiles = useBeneficiaryStore((s) => s.resetProfiles);
  const profileChanges = useBeneficiaryStore((s) => s.changes);

  const payrollPayments = usePayrollStore((s) => s.payments);
  const payrollCycles = usePayrollStore((s) => s.cycles);
  const resetPayroll = usePayrollStore((s) => s.resetPayroll);

  const grievanceCases = useGrievanceStore((s) => s.cases);
  const resetGrievances = useGrievanceStore((s) => s.resetGrievances);

  const trainingParticipants = useTrainingStore((s) => s.participants);
  const resetTraining = useTrainingStore((s) => s.resetTraining);

  useEffect(() => {
    const savedRole = localStorage.getItem("mcbp-role");
    const savedLang = localStorage.getItem("mcbp-lang");

    if (savedRole && roles.some((r) => r.id === savedRole)) {
      setRoleId(savedRole);
    }

    if (savedLang === "en" || savedLang === "bn") {
      setLang(savedLang);
    }
  }, []);

  const t = (en: string, bn: string) =>
    lang === "bn" ? bn : en;

  const role = roles.find((r) => r.id === roleId) ?? roles[0];
  const isNationalRole = nationalRoles.includes(roleId);
  const canViewGis = isNationalRole || roleId === "uwao";
  const canViewAi = aiRoles.includes(roleId);

  const pendingApproval = applications.filter(
    (a) => a.status === "approval_pending"
  ).length;

  const pendingField = applications.filter(
    (a) => a.status === "field_pending"
  ).length;

  const openGrievances = grievanceCases.filter(
    (c) =>
      c.queue === "programme" &&
      !["resolved", "closed"].includes(c.status)
  ).length;

  const bounced = payrollPayments.filter(
    (p) => p.status === "bounced"
  ).length;

  const pendingReviews = profileChanges.filter(
    (c) => c.state === "pending"
  ).length;

  const trainingCompleted = trainingParticipants.filter(
    (p) => p.attended
  ).length;

  const trainingCertificates = trainingParticipants.filter(
    (p) => Boolean(p.certificateId)
  ).length;

  const currentMenu = sections
    .flatMap((section) => section.items)
    .find((item) => item[0] === path);

  const title =
    path === "/dashboard"
      ? isNationalRole
        ? t(
            "Programme operations overview",
            "কর্মসূচির কার্যক্রম"
          )
        : t(
            "Good morning, Nasrin. Here is your upazila today.",
            "শুভ সকাল, নাসরিন। আজকের উপজেলার চিত্র দেখুন।"
          )
      : currentMenu
        ? t(currentMenu[1], currentMenu[2])
        : "Dashboard";

  const cards = [
    [
      "Applications awaiting my decision",
      "আমার সিদ্ধান্তের অপেক্ষায় আবেদন",
      String(46 + pendingApproval),
      "12 older than 5 days",
      "৫ দিনের বেশি পুরোনো ১২টি",
      "magenta",
      FileText,
    ],
    [
      "Field verifications pending",
      "মাঠ যাচাই অপেক্ষমাণ",
      String(117 + pendingField),
      "83% within SLA",
      "৮৩% নির্ধারিত সময়ে",
      "amber",
      Map,
    ],
    [
      "Paid this cycle",
      "এই চক্রে পরিশোধিত",
      "14,208",
      `${
        payrollPayments.filter((p) =>
          ["paid", "repaid"].includes(p.status)
        ).length
      } mock transactions`,
      "ডেমো পেমেন্ট সিমুলেশন",
      "green",
      Wallet,
    ],
    [
      "Open grievances",
      "চলমান অভিযোগ",
      String(19 + openGrievances),
      `${openGrievances} current demo records`,
      `${openGrievances}টি চলমান ডেমো অভিযোগ`,
      "blue",
      MessageSquareWarning,
    ],
    [
      "Training completions",
      "প্রশিক্ষণ সম্পন্ন",
      String(trainingCompleted),
      `${trainingCertificates} certificates`,
      `${trainingCertificates}টি সনদ`,
      "green",
      GraduationCap,
    ],
  ] as const;

  function notify(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2500);
  }

  function updateRole(nextRole: string) {
    setRoleId(nextRole);
    localStorage.setItem("mcbp-role", nextRole);
    setPath("/dashboard");
    setMobileOpen(false);
  }

  function updateLanguage(nextLang: Lang) {
    setLang(nextLang);
    localStorage.setItem("mcbp-lang", nextLang);
  }

  function navigate(next: string) {
    // MCBP_SELF_SERVICE_MIS_23C_V1
    if (next === "/self-service") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Self-service MIS requires a national demo role.");
        return;
      }
      setPath("/self-service");
      setMobileOpen(false);
      return;
    }
    // MCBP_PERFORMANCE_D22_V1
    if (next === "/performance-tests") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Performance tests require a national demo role.");
        return;
      }
      setPath("/performance-tests");
      setMobileOpen(false);
      return;
    }
    // MCBP_RELEASE_D21_V1
    if (next === "/release-management") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Release Management requires a national demo role.");
        return;
      }
      setPath("/release-management");
      setMobileOpen(false);
      return;
    }
    // MCBP_CAPACITY_D20_V1
    if (next === "/capacity") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Capacity console requires a national demo role.");
        return;
      }
      setPath("/capacity");
      setMobileOpen(false);
      return;
    }
    // MCBP_GIS_GOVERNANCE_D19_V1
    if (next === "/gis-governance") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("GIS Governance requires a national demo role.");
        return;
      }

      setPath("/gis-governance");
      setMobileOpen(false);
      return;
    }
    // MCBP_AI_GOVERNANCE_D18_V1
    if (next === "/ai-governance") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("AI Governance requires a national demo role.");
        return;
      }
      setPath("/ai-governance");
      setMobileOpen(false);
      return;
    }
    // MCBP_PAYROLL_D17_UNIFIED_V1
    if (next === "/payroll-monitor") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Payroll Monitor requires a national demo role.");
        return;
      }

      setPath("/payroll-monitor");
      setMobileOpen(false);
      return;
    }
    // MCBP_DATAGOV_D16_UNIFIED_V1
    if (next === "/data-governance") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Data Governance requires a national demo role.");
        return;
      }
      setPath("/data-governance");
      setMobileOpen(false);
      return;
    }
    // MCBP_BACKUP_D15_UNIFIED_V1
    if (next === "/backup-dr") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Backup & DR requires a national demo role.");
        return;
      }
      setPath("/backup-dr");
      setMobileOpen(false);
      return;
    }
    // MCBP_SECURITY_D14_UNIFIED_V1
    if (next === "/security-center") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Security Centre requires a national demo role.");
        return;
      }

      setPath("/security-center");
      setMobileOpen(false);
      return;
    }
    // MCBP_CICD_UNIFIED_V1
    if (next === "/cicd") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("CI/CD requires a national demo role.");
        return;
      }
      setPath("/cicd");
      setMobileOpen(false);
      return;
    }
    // MCBP_OBSERVABILITY_UNIFIED_V1
    if (next === "/observability") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("Observability requires a national demo role.");
        return;
      }

      setPath("/observability");
      setMobileOpen(false);
      return;
    }
    // MCBP_XROAD_UNIFIED_V1
    if (next === "/xroad") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("X-Road console requires a national demo role.");
        return;
      }
      setPath("/xroad");
      setMobileOpen(false);
      return;
    }
    // MCBP_GATEWAY_UNIFIED_V1
    if (next === "/gateway") {
      if (!["admin", "executive"].includes(roleId)) {
        notify("API Gateway requires a national demo role.");
        return;
      }
      setPath("/gateway");
      setMobileOpen(false);
      return;
    }
    // MCBP_SS14_UNIFIED_V1
    if (next === "/multi-scheme") {
      if (!["admin", "executive", "uwao"].includes(roleId)) {
        notify("Multi-scheme management requires a configuration role.");
        return;
      }

      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      setPath("/multi-scheme");
      setMobileOpen(false);
      return;
    }
    const unifiedModules = [
      "/executive",
      "/data-hub",
      "/gis",
      "/ai",
      "/mobile",
      "/access",
      "/helpdesk",
      "/schemes",
    ];

    if (next === "/dashboard" && isNationalRole) {
      setPath("/executive");
      setMobileOpen(false);
      return;
    }

    if (unifiedModules.includes(next)) {
      if (next === "/data-hub" && !isNationalRole) {
        notify("Data Hub requires a national role.");
        return;
      }

      if (next === "/gis" && !canViewGis) {
        notify("GIS is unavailable for this role.");
        return;
      }

      if (next === "/ai" && !canViewAi) {
        notify("AI Assistant is unavailable for this role.");
        return;
      }

      if (
        next === "/access" &&
        !["admin", "executive"].includes(roleId)
      ) {
        notify("Users & Access requires a national role.");
        return;
      }

      if (
        next === "/helpdesk" &&
        !["admin", "executive", "uwao", "grm"].includes(roleId)
      ) {
        notify("Helpdesk is unavailable for this role.");
        return;
      }

      if (
        next === "/schemes" &&
        !["admin", "executive", "uwao"].includes(roleId)
      ) {
        notify("Module Builder is unavailable for this role.");
        return;
      }

      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);

      setPath(next);
      setMobileOpen(false);
      return;
    }
    if (next === "/schemes") {
      if (!["admin", "executive", "uwao"].includes(roleId)) {
        notify("Module Builder is available to configuration roles only.");
        return;
      }
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/schemes");
      return;
    }
    if (next === "/helpdesk") {
      if (!["admin", "executive", "uwao", "grm"].includes(roleId)) {
        notify("Helpdesk demo requires a support or supervisory role.");
        return;
      }
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/helpdesk");
      return;
    }
    if (next === "/access") {
      if (roleId !== "admin" && roleId !== "executive") {
        notify("Users & Access requires Administrator or Programme Executive demo role.");
        return;
      }
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/access");
      return;
    }
    if (next === "/mobile") {
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/mobile");
      return;
    }
    if (next === "/ai") {
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/ai");
      return;
    }
    setMobileOpen(false);

    // All standalone modules are reached from the main sidebar.
    if (next === "/dashboard" && isNationalRole) {
      window.location.assign("/executive");
      return;
    }

    if (next === "/gis") {
      if (!canViewGis) {
        notify(
          t(
            "GIS is not available for this demo role.",
            "এই ডেমো রোলে জিআইএস দেখা যাবে না।"
          )
        );
        return;
      }

      window.location.assign("/gis");
      return;
    }

    if (next === "/ai") {
      if (!canViewAi) {
        notify(
          t(
            "AI Assistant is available to UWAO, Programme Executive and Administrator.",
            "এআই সহকারী শুধু উপজেলা কর্মকর্তা, প্রোগ্রাম নির্বাহী ও প্রশাসকের জন্য।"
          )
        );
        return;
      }

      // Store the active role and language before opening AI.
      localStorage.setItem("mcbp-role", roleId);
      localStorage.setItem("mcbp-lang", lang);
      window.location.assign("/ai");
      return;
    }

    if (next === "/data-hub") {
      if (!isNationalRole) {
        notify(
          t(
            "Select Programme Executive or System Administrator.",
            "প্রোগ্রাম নির্বাহী বা সিস্টেম প্রশাসক নির্বাচন করুন।"
          )
        );
        return;
      }

      window.location.assign("/data-hub");
      return;
    }

    if (standaloneRoutes.includes(next)) {
      window.location.assign(next);
      return;
    }

    setPath(next);
  }

  function resetDemo() {
    resetApplications();
    resetProfiles();
    resetPayroll();
    resetGrievances();
    resetTraining();

    localStorage.removeItem("mcbp-lang");
    localStorage.removeItem("mcbp-role");
    localStorage.removeItem("mcbp-ai-proposals");

    setLang("en");
    setRoleId("uwao");
    setPath("/dashboard");

    notify("Demo reset");
  }

  const visibleSections = sections
    .filter((section) => {
      if (
        ["field", "trainer", "finance", "finance_checker", "grm"]
          .includes(roleId)
      ) {
        return [
          "BENEFICIARY LIFECYCLE",
          "INTELLIGENCE",
        ].includes(section.en);
      }

      return true;
    })
    .map((section) => ({
      ...section,
      items: section.items.filter(([href]) => {
        if (href === "/data-hub" && !isNationalRole) {
          return false;
        }

        if (href === "/gis" && !canViewGis) {
          return false;
        }

        if (href === "/ai" && !canViewAi) {
          return false;
        }

        return true;
      }),
    }))
    .filter((section) => section.items.length > 0);

  return (
    <div className={lang === "bn" ? "app bn" : "app"}>
      <header className="top">
        <button
          className="btn mobile-menu"
          aria-label="Toggle menu"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          <Menu size={19} />
        </button>

        <div className="logo">
          <HeartHandshake size={22} />
        </div>

        <div className="brand">
          <b>MCBP-MIS</b>
          <span>
            {t(
              "Mother & Child Benefit Programme",
              "মা ও শিশু ভাতা কর্মসূচি"
            )}
          </span>
        </div>

        {/* MCBP_NAVBAR_SEARCH_V1 */}
        <NavbarSearch
          lang={lang}
          items={visibleSections.flatMap((section) =>
            section.items.map(([href, en, bn]) => ({
              href,
              en,
              bn,
              section: t(section.en, section.bn),
            }))
          )}
          onNavigate={navigate}
        />
<div className="lang">
          <button
            className={lang === "en" ? "on" : ""}
            onClick={() => updateLanguage("en")}
          >
            EN
          </button>

          <button
            className={lang === "bn" ? "on" : ""}
            onClick={() => updateLanguage("bn")}
          >
            বাংলা
          </button>
        </div>

        <Bell size={20} />

        {/* MCBP_FIXED_SHELL_V2 */}
          <details className="mcbp-profile-menu">
            <summary
              className="mcbp-profile-trigger"
              aria-label="Switch demo role"
            >
              <div className="av">{role.initials}</div>
              <div className="who">
                <b>{t(role.en, role.bn)}</b>
                <span>{role.geo}</span>
              </div>
              <span
                className="mcbp-profile-arrow"
                aria-hidden="true"
              />
            </summary>

            <div className="mcbp-role-list">
              <div className="mcbp-role-title">
                {t("Switch demo role", "Role selection")}
              </div>

              {roles.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={
                    roleId === item.id
                      ? "mcbp-role-item selected"
                      : "mcbp-role-item"
                  }
                  onClick={(event) => {
                    updateRole(item.id);
                    event.currentTarget
                      .closest("details")
                      ?.removeAttribute("open");
                  }}
                >
                  <span className="mcbp-role-avatar">
                    {item.initials}
                  </span>
                  <span className="mcbp-role-description">
                    <strong>{t(item.en, item.bn)}</strong>
                    <small>{item.geo}</small>
                  </span>
                  {roleId === item.id && (
                    <span className="mcbp-role-check">
                      &#10003;
                    </span>
                  )}
                </button>
              ))}
            </div>
          </details>
      </header>

      <div className="main">
        <aside className={mobileOpen ? "side open" : "side"}>
          {visibleSections.map((section) => (
            <div key={section.en}>
              <h6>{t(section.en, section.bn)}</h6>

              {section.items.map(([href, en, bn, Icon]) => (
                <button
                  key={href}
                  className={path === href ? "nav on" : "nav"}
                  onClick={() => navigate(href)}
                >
                  <Icon size={17} />
                  <span>{t(en, bn)}</span>
                </button>
              ))}
            </div>
          ))}
        </aside>

        <main className="content">
          <div className="crumb">
            {t(
              "Home / Kaunia Upazila, Rangpur",
              "হোম / কাউনিয়া উপজেলা, রংপুর"
            )}
          </div>

          <div className="hrow">
            <div>
              <h1>{title}</h1>
              <p className="sub">
                {t(
                  "Role-aware workspace · fictional data · frontend-only demo",
                  "ভূমিকা অনুযায়ী ওয়ার্কস্পেস · কাল্পনিক তথ্য · ফ্রন্টএন্ড ডেমো"
                )}
              </p>
            </div>

            <div className="actions">
              <button className="btn">
                <CalendarDays size={15} />
                13 Nov 2026
              </button>

              <button
                className="btn primary"
                onClick={() =>
                  notify(
                    t(
                      "Scenario guide not yet implemented",
                      "সিনারিও গাইড এখনো তৈরি হয়নি"
                    )
                  )
                }
              >
                {t("Scenario guide", "সিনারিও গাইড")}
                <ArrowRight size={15} />
              </button>
            </div>
          </div>

          {[
            "/executive",
            "/data-hub",
            "/gis",
            "/ai",
            "/mobile",
            "/access",
            "/helpdesk",
            "/schemes",
            "/multi-scheme",
            "/gateway",
            "/xroad",
            "/observability",
            "/cicd",
            "/security-center",
            "/backup-dr",
            "/data-governance",
            "/payroll-monitor",
            "/ai-governance",
            "/gis-governance",
            "/capacity",
            "/release-management",
            "/performance-tests",
            "/self-service",
          ].includes(path) ? (
            <div
              key={`${path}-${roleId}-${lang}`}
              className="mcbp-embedded-module"
            >
              <style>{`
                .mcbp-embedded-module {
                  width: 100%;
                  min-width: 0;
                }

                .mcbp-embedded-module > div > header,
                .mcbp-embedded-module > main > header,
                .mcbp-embedded-module .ai-top,
                .mcbp-embedded-module .mobile-top,
                .mcbp-embedded-module .access-top,
                .mcbp-embedded-module .hd-top,
                .mcbp-embedded-module .s13-top {
                  display: none !important;
                }

                .mcbp-embedded-module .ai-root,
                .mcbp-embedded-module .mobile-demo,
                .mcbp-embedded-module .access-page,
                .mcbp-embedded-module .hd-root,
                .mcbp-embedded-module .ss13 {
                  padding: 0 !important;
                  min-height: 0 !important;
                  background: transparent !important;
                }

                .mcbp-embedded-module > div {
                  min-width: 0;
                  max-width: 100%;
                }
              `}</style>

              {path === "/executive" ? (
                <UnifiedExecutive />
              ) : path === "/data-hub" ? (
                <UnifiedDataHub />
              ) : path === "/gis" ? (
                <UnifiedGIS />
              ) : path === "/ai" ? (
                <UnifiedAI />
              ) : path === "/mobile" ? (
                <UnifiedMobile />
              ) : path === "/access" ? (
                <UnifiedAccess />
              ) : path === "/helpdesk" ? (
                <UnifiedHelpdesk />
              ) : path === "/schemes" ? (
                <UnifiedBuilder />
              ) : path === "/multi-scheme" ? (
                <MultiSchemePanel lang={lang} roleId={roleId} />
              ) : path === "/gateway" ? (
                <GatewayPanel lang={lang} roleId={roleId} />
              ) : path === "/xroad" ? (
                <XRoadPanel lang={lang} roleId={roleId} />
              ) : path === "/observability" ? (
                <ObservabilityPanel lang={lang} roleId={roleId} />
              ) : path === "/cicd" ? (
                <CICDPanel lang={lang} roleId={roleId} />
              ) : path === "/security-center" ? (
                <SecurityCenterPanel lang={lang} roleId={roleId} />
              ) : path === "/backup-dr" ? (
                <BackupDRPanel lang={lang} roleId={roleId} />
              ) : path === "/data-governance" ? (
                <DataGovernancePanel lang={lang} roleId={roleId} />
              ) : path === "/payroll-monitor" ? (
                <PayrollMonitorPanel lang={lang} roleId={roleId} />
              ) : path === "/ai-governance" ? (
                <AIGovernancePanel lang={lang} roleId={roleId} />
              ) : path === "/gis-governance" ? (
                <GISGovernancePanel lang={lang} roleId={roleId} />
              ) : path === "/capacity" ? (
                <CapacityPanel lang={lang} roleId={roleId} />
              ) : path === "/release-management" ? (
                <ReleaseManagementPanel lang={lang} roleId={roleId} />
              ) : path === "/performance-tests" ? (
                <PerformanceTestPanel lang={lang} roleId={roleId} />
              ) : (
                <SelfServiceMISPanel lang={lang} roleId={roleId} />
              )}
            </div>
          ) : path === "/applications" ? (
            <ApplicationsPanel lang={lang} roleId={roleId} />
          ) : path === "/beneficiaries" ? (
            <BeneficiariesPanel lang={lang} roleId={roleId} />
          ) : path === "/payroll" ? (
            <PayrollPanel lang={lang} roleId={roleId} />
          ) : path === "/grievances" ? (
            <GrievancesPanel lang={lang} roleId={roleId} />
          ) : path === "/training" ? (
            <TrainingPanel lang={lang} roleId={roleId} />
          ) : path === "/dashboard" ? (
            <>
              <div className="grid kpis">
                {cards.map(
                  ([en, bn, value, detailEn, detailBn, color, Icon]) => (
                    <div className="card stat" key={en}>
                      <div className="stat-head">
                        <span>{t(en, bn)}</span>
                        <span className={`stat-icon ${color}`}>
                          <Icon size={19} />
                        </span>
                      </div>

                      <strong>{value}</strong>

                      <small className={color}>
                        {t(detailEn, detailBn)}
                      </small>
                    </div>
                  )
                )}
              </div>

              <div className="grid two">
                <section className="card">
                  <div className="card-title">
                    <h2>
                      {t(
                        "My approval queue",
                        "আমার অনুমোদন তালিকা"
                      )}
                    </h2>

                    <button
                      className="link"
                      onClick={() => navigate("/applications")}
                    >
                      {t("View all", "সব দেখুন")}
                    </button>
                  </div>

                  <div style={{ overflowX: "auto" }}>
                    <table>
                      <thead>
                        <tr>
                          <th>{t("Application", "আবেদন")}</th>
                          <th>{t("Applicant", "আবেদনকারী")}</th>
                          <th>{t("Status", "অবস্থা")}</th>
                          <th>{t("Action", "অ্যাকশন")}</th>
                        </tr>
                      </thead>

                      <tbody>
                        {applications.slice(0, 5).map((a) => (
                          <tr key={a.id}>
                            <td className="mono">{a.id}</td>

                            <td>
                              {lang === "bn"
                                ? a.nameBn || a.nameEn
                                : a.nameEn}
                            </td>

                            <td>
                              <span
                                className={`pill ${
                                  [
                                    "approved",
                                    "enrolled",
                                    "field_completed",
                                  ].includes(a.status)
                                    ? "g"
                                    : "a"
                                }`}
                              >
                                {t(
                                  ...(statusNames[a.status] ?? [
                                    a.status,
                                    a.status,
                                  ])
                                )}
                              </span>
                            </td>

                            <td>
                              <button
                                className="link"
                                onClick={() =>
                                  navigate(
                                    a.status === "enrolled"
                                      ? "/beneficiaries"
                                      : "/applications"
                                  )
                                }
                              >
                                {t("Open", "খুলুন")}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>

                <section className="card">
                  <div className="card-title">
                    <h2>
                      {t(
                        "Union quota progress",
                        "ইউনিয়ন কোটা অগ্রগতি"
                      )}
                    </h2>
                    <span className="muted">FY 2026</span>
                  </div>

                  {[
                    ["Kaunia", "82%", "246 / 300", "g"],
                    ["Haragach", "68%", "204 / 300", "m"],
                    ["Balarhat", "54%", "162 / 300", "a"],
                  ].map(([name, percent, count, color]) => (
                    <div className="quota" key={name}>
                      <div>
                        <b>{name}</b>
                        <span>{count}</span>
                      </div>

                      <div className="bar">
                        <i
                          className={color}
                          style={{ width: percent }}
                        />
                      </div>

                      <small>{percent}</small>
                    </div>
                  ))}
                </section>
              </div>

              <div className="grid two">
                <section className="card">
                  <div className="card-title">
                    <h2>
                      {t(
                        "Applications · last 8 weeks",
                        "আবেদন · গত ৮ সপ্তাহ"
                      )}
                    </h2>

                    <span className="muted">
                      {t(
                        "Submitted / approved",
                        "জমা / অনুমোদিত"
                      )}
                    </span>
                  </div>

                  <div className="chart">
                    {[42, 55, 49, 66, 58, 74, 62, 81].map(
                      (height, index) => (
                        <div className="bar-col" key={index}>
                          <span
                            style={{ height: `${height}%` }}
                          />
                          <span
                            style={{
                              height: `${Math.max(
                                20,
                                height - 28
                              )}%`,
                            }}
                          />
                          <label>W{index + 1}</label>
                        </div>
                      )
                    )}
                  </div>

                  <div className="legend">
                    <span>
                      <i className="lg green" />
                      {t("Submitted", "জমা")}
                    </span>
                    <span>
                      <i className="lg magenta" />
                      {t("Approved", "অনুমোদিত")}
                    </span>
                  </div>
                </section>

                <section className="card">
                  <div className="card-title">
                    <h2>
                      {t("Today's indicators", "আজকের সূচক")}
                    </h2>
                    <span className="pill g">
                      {t("Demo", "ডেমো")}
                    </span>
                  </div>

                  {[
                    ["Field visits scheduled", "মাঠ পরিদর্শন", "36"],
                    [
                      "Profile reviews pending",
                      "প্রোফাইল রিভিউ",
                      String(pendingReviews),
                    ],
                    [
                      "Payroll cycles",
                      "পেরোল চক্র",
                      String(payrollCycles.length),
                    ],
                    [
                      "Bounced payments",
                      "ব্যর্থ পেমেন্ট",
                      String(bounced),
                    ],
                    [
                      "Grievance cases in demo",
                      "ডেমো অভিযোগ",
                      String(grievanceCases.length),
                    ],
                    [
                      "Training completions",
                      "প্রশিক্ষণ সম্পন্ন",
                      `${trainingCompleted} · ${trainingCertificates} certs`,
                    ],
                  ].map(([en, bn, value]) => (
                    <div className="indicator" key={en}>
                      <span>{t(en, bn)}</span>
                      <b>{value}</b>
                    </div>
                  ))}
                </section>
              </div>

              <section className="advisory">
                <div className="ai-mark">
                  <Bot size={20} />
                </div>

                <div>
                  <b>
                    {t(
                      "Advisory insight · human review required",
                      "পরামর্শ · মানব পর্যালোচনা প্রয়োজন"
                    )}
                  </b>

                  <p>
                    {t(
                      `${bounced} simulated payment bounce(s) and ${openGrievances} active programme grievance(s) are available for investigation. This is not an AI decision.`,
                      `${bounced}টি সিমুলেটেড পেমেন্ট ব্যর্থ এবং ${openGrievances}টি চলমান অভিযোগ তদন্তের জন্য রয়েছে। এটি এআই সিদ্ধান্ত নয়।`
                    )}
                  </p>
                </div>

                <button
                  className="btn"
                  onClick={() => navigate("/grievances")}
                >
                  {t("Review cases", "অভিযোগ দেখুন")}
                </button>
              </section>
            </>
          ) : (
            <section className="card placeholder">
              <div className="placeholder-icon">
                <Layers3 size={28} />
              </div>

              <h2>
                {t(
                  "Module not yet implemented",
                  "মডিউল এখনো তৈরি হয়নি"
                )}
              </h2>

              <p>
                {t(
                  "This module will be added in the next development delivery.",
                  "এই মডিউল পরবর্তী ডেভেলপমেন্টে যুক্ত হবে।"
                )}
              </p>

              <button
                className="btn primary"
                onClick={() => navigate("/dashboard")}
              >
                {t(
                  "Return to dashboard",
                  "ড্যাশবোর্ডে ফিরুন"
                )}
              </button>
            </section>
          )}
        </main>
      </div>

      {toast && <div className="toast">{toast}</div>}

      <footer>
        {t(
          "Frontend-only demonstration · Fictional data · Demo-enforced RBAC",
          "ফ্রন্টএন্ড ডেমো · কাল্পনিক তথ্য · ডেমো অনুমতি"
        )}

        <button onClick={resetDemo}>
          <RotateCcw size={13} />
          {t("Reset demo", "ডেমো রিসেট")}
        </button>

        <select
          aria-label="Demo role"
          value={roleId}
          onChange={(e) => updateRole(e.target.value)}
        >
          {roles.map((item) => (
            <option value={item.id} key={item.id}>
              {item.en}
            </option>
          ))}
        </select>
      </footer>
    </div>
  );
}
